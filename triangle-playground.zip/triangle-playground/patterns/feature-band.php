<?php
/**
 * Title: Dark feature band
 * Slug: triangle-playground/feature-band
 * Categories: triangle
 * Description: Six reasons on deep navy.
 */
?>
<!-- wp:group {"tagName":"section","backgroundColor":"deep","textColor":"white","align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group alignfull has-white-color has-deep-background-color has-text-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"textColor":"white"} -->
<h2 class="wp-block-heading has-white-color has-text-color">Why a VIK package</h2>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"constrained","contentSize":"680px","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"textColor":"mist","fontSize":"large"} -->
<p class="has-mist-color has-text-color has-large-font-size">Fewer parts to source, fewer mismatches on site, less time on the lift.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color">Assembled and tested at the factory</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist","fontSize":"small"} -->
<p class="has-mist-color has-text-color has-small-font-size">Fan, shutter, guard and wall box arrive as one unit.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color">Serviced from inside</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist","fontSize":"small"} -->
<p class="has-mist-color has-text-color has-small-font-size">Belts, pulleys and motor are reachable from inside. No outside lift needed.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color">Automatic belt tensioner</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist","fontSize":"small"} -->
<p class="has-mist-color has-text-color has-small-font-size">On ODP and TE motors up to 1 1/2 HP. Longer belt life, less adjustment.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color">Galvanized wall box</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist","fontSize":"small"} -->
<p class="has-mist-color has-text-color has-small-font-size">Heavy-gauge galvanized housing for a simple, secure exterior wall mount.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color">Rolled inlet venturi</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist","fontSize":"small"} -->
<p class="has-mist-color has-text-color has-small-font-size">Bronze powder coated, for efficient airflow.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color">Balanced airflow</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist","fontSize":"small"} -->
<p class="has-mist-color has-text-color has-small-font-size">Pair it with a Triangle supply fan to keep building pressure right.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
