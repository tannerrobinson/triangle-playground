<?php
/**
 * Title: Triangle header
 * Slug: triangle-playground/header
 * Inserter: no
 * Description: Utility bar, logo, menu and quote button.
 */
?>
<!-- wp:group {"backgroundColor":"deep","textColor":"mist","align":"full","style":{"spacing":{"padding":{"top":"10px","bottom":"10px"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<div class="wp-block-group alignfull has-mist-color has-deep-background-color has-text-color has-background" style="margin-top:0;margin-bottom:0;padding-top:10px;padding-bottom:10px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.06em"}}} -->
<p class="has-mono-font-family has-small-font-size" style="letter-spacing:0.06em;text-transform:uppercase">Fan manufacturer since 1948 · Jacksonville, Arkansas</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"white","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.06em"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}}} -->
<p class="has-white-color has-text-color has-link-color has-mono-font-family has-small-font-size" style="letter-spacing:0.06em;text-transform:uppercase">Support <a href="tel:+15019827558">(501) 982-7558</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"backgroundColor":"navy","align":"full","style":{"spacing":{"padding":{"top":"14px","bottom":"14px"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<div class="wp-block-group alignfull has-navy-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:14px;padding-bottom:14px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:image {"width":"108px","linkDestination":"custom"} -->
<figure class="wp-block-image is-resized"><a href="/"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/triangle-logo.svg' ) ); ?>" alt="Triangle Engineering" style="width:108px;height:auto"/></a></figure>
<!-- /wp:image -->

<!-- wp:navigation {"textColor":"white","overlayBackgroundColor":"navy","overlayTextColor":"white","layout":{"type":"flex","justifyContent":"center"}} -->
<!-- wp:navigation-link {"label":"Fans","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Parts","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Where to buy","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Resources","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Company","url":"#","kind":"custom","isTopLevelLink":true} /-->
<!-- /wp:navigation -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Request a quote</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
