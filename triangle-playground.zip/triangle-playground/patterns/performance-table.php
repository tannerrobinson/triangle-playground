<?php
/**
 * Title: Performance table
 * Slug: triangle-playground/performance-table
 * Categories: triangle
 * Description: Airflow by motor at each static pressure.
 */
?>
<!-- wp:group {"tagName":"section","backgroundColor":"white","align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"0","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group alignfull has-white-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"32%"} -->
<div class="wp-block-column" style="flex-basis:32%"><!-- wp:paragraph {"textColor":"muted","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-muted-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Performance</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"performance"} -->
<h2 id="performance" class="wp-block-heading">Airflow by size and motor</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"body"} -->
<p class="has-body-color has-text-color">CFM at each static pressure. Static pressure is the resistance the fan works against, in inches of water.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="#">Full spec sheet, all sizes (PDF)</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"68%"} -->
<div class="wp-block-column" style="flex-basis:68%"><!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><strong>36 in. blade</strong> · 40 3/4 x 40 3/4 in. over bolt heads</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Motor</th><th class="has-text-align-right" data-align="right">CFM at 0 in.</th><th class="has-text-align-right" data-align="right">0.125 in.</th><th class="has-text-align-right" data-align="right">0.25 in.</th><th class="has-text-align-right" data-align="right">0.50 in.</th><th class="has-text-align-right" data-align="right">Weight, lb</th></tr></thead><tbody><tr><td>1/2 HP</td><td class="has-text-align-right" data-align="right">10,800</td><td class="has-text-align-right" data-align="right">8,840</td><td class="has-text-align-right" data-align="right">6,550</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">200</td></tr><tr><td>3/4 HP</td><td class="has-text-align-right" data-align="right">12,600</td><td class="has-text-align-right" data-align="right">10,550</td><td class="has-text-align-right" data-align="right">6,880</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">205</td></tr><tr><td>1 HP</td><td class="has-text-align-right" data-align="right">13,340</td><td class="has-text-align-right" data-align="right">11,500</td><td class="has-text-align-right" data-align="right">9,160</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">215</td></tr><tr><td>1 1/2 HP</td><td class="has-text-align-right" data-align="right">14,790</td><td class="has-text-align-right" data-align="right">13,080</td><td class="has-text-align-right" data-align="right">11,440</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">230</td></tr><tr><td>2 HP</td><td class="has-text-align-right" data-align="right">16,900</td><td class="has-text-align-right" data-align="right">15,440</td><td class="has-text-align-right" data-align="right">13,380</td><td class="has-text-align-right" data-align="right">8,250</td><td class="has-text-align-right" data-align="right">270</td></tr><tr><td>3 HP</td><td class="has-text-align-right" data-align="right">15,400</td><td class="has-text-align-right" data-align="right">14,200</td><td class="has-text-align-right" data-align="right">13,000</td><td class="has-text-align-right" data-align="right">9,970</td><td class="has-text-align-right" data-align="right">327</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size">All seven sizes, 24 to 60 in., are in the spec sheet.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
