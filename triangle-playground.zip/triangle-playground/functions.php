<?php
/**
 * Triangle Playground theme setup.
 */

// A "Triangle" category in the pattern inserter.
add_action( 'init', function () {
	register_block_pattern_category( 'triangle', array( 'label' => 'Triangle' ) );
} );

/**
 * Creates the sample VIK product page and, on a fresh site, makes it the home page.
 *
 * When a newer version of this theme ships a newer sample page, an untouched copy is
 * refreshed. A copy someone has edited is left alone.
 */
function triangle_playground_install_demo() {
	// Block markup must be saved by someone allowed to save unfiltered HTML, or WordPress strips parts of it.
	if ( ! current_user_can( 'unfiltered_html' ) ) {
		return 0;
	}
	$content = file_get_contents( get_theme_file_path( 'inc/vik-page.html' ) );
	if ( false === $content ) {
		return 0;
	}

	// Fingerprints of every sample page this theme has shipped. The first is version 1.0.
	$shipped   = (array) get_option( 'triangle_playground_demo_hashes', array() );
	$shipped[] = 'e340ebe9883226a2f23bd9089fa9ba35142f1963a59cb5e2572febf6755200e4';
	$shipped[] = 'e282c7f40aec06f1823b81351f3ae2cc27e58c76a65bc8b1ada4762038c2c81e'; // version 1.1
	$shipped[] = 'f5efcb0b0505c519feb0fbc965ed4bcd68a5ce8a568d116c1798552c17939cb6'; // version 1.2

	$page = get_page_by_path( 'vik-exhaust-package', OBJECT, 'page' );
	if ( $page ) {
		$page_id = $page->ID;
		$current = hash( 'sha256', $page->post_content );
		if ( hash( 'sha256', $content ) !== $current && in_array( $current, $shipped, true ) ) {
			wp_update_post( array(
				'ID'           => $page_id,
				'post_content' => wp_slash( $content ),
			) );
		}
	} else {
		$page_id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => 'VIK exhaust package',
			'post_name'    => 'vik-exhaust-package',
			'post_content' => wp_slash( $content ),
		) );
	}

	if ( $page_id && ! is_wp_error( $page_id ) ) {
		$shipped[] = hash( 'sha256', get_post_field( 'post_content', $page_id, 'raw' ) );
		update_option( 'triangle_playground_demo_hashes', array_values( array_unique( $shipped ) ), false );
		update_post_meta( $page_id, '_wp_page_template', 'page-product' );
		if ( 'posts' === get_option( 'show_on_front' ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $page_id );
		}
	}
	update_option( 'triangle_playground_demo_version', wp_get_theme( get_template() )->get( 'Version' ) );
	return $page_id;
}
add_action( 'after_switch_theme', 'triangle_playground_install_demo' );

// After uploading a newer version of the theme, run the setup once more.
add_action( 'init', function () {
	if ( wp_get_theme( get_template() )->get( 'Version' ) !== get_option( 'triangle_playground_demo_version' ) ) {
		triangle_playground_install_demo();
	}
} );
