<?php
/**
 * Title: Product hero
 * Slug: triangle-playground/product-hero
 * Categories: triangle
 * Description: Photo, name, spec plate and buttons for a product page.
 */
?>
<!-- wp:group {"tagName":"section","backgroundColor":"white","align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group alignfull has-white-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"textColor":"muted","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-muted-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Home / Fans / Wall exhaust and supply / VIK exhaust packages</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"64px"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"50%"} -->
<div class="wp-block-column" style="flex-basis:50%"><!-- wp:group {"backgroundColor":"white","className":"photo-frame","style":{"border":{"color":"#D8DADD","width":"1px","style":"solid"},"spacing":{"padding":{"top":"24px","bottom":"24px","left":"24px","right":"24px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group photo-frame has-border-color has-white-background-color has-background" style="border-color:#D8DADD;border-style:solid;border-width:1px;padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px"><!-- wp:image {"width":"500px","align":"center"} -->
<figure class="wp-block-image aligncenter is-resized"><img src="https://trianglefans.com/wp-content/uploads/2019/10/VIK-back-open-grill_web.jpg" alt="VIK exhaust package seen from outside: galvanized wall box with a brown-framed gravity shutter, blades partly open" style="width:500px;height:auto"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"50%","style":{"spacing":{"blockGap":"22px"}}} -->
<div class="wp-block-column" style="flex-basis:50%"><!-- wp:group {"style":{"spacing":{"blockGap":"14px"}},"layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"series-badge"} -->
<p class="series-badge">VIK series</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-muted-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Wall exhaust · Belt drive</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"10px"}},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":1,"style":{"typography":{"fontSize":"clamp(36px, 3.4vw, 48px)","lineHeight":"1"}}} -->
<h1 class="wp-block-heading" style="font-size:clamp(36px, 3.4vw, 48px);line-height:1">VIK exhaust package</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"body","style":{"typography":{"fontSize":"19px","lineHeight":"1.3","fontWeight":"700","textTransform":"uppercase"}}} -->
<p class="has-body-color has-text-color" style="font-size:19px;font-weight:700;line-height:1.3;text-transform:uppercase">Fan, shutter, guard and wall box in one unit</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"textColor":"body","className":"hero-intro","style":{"typography":{"fontSize":"18px"}}} -->
<p class="hero-intro has-body-color has-text-color" style="font-size:18px">Our heavy-duty VI belt-drive exhaust fan with the VIG OSHA guard and IWS gravity shutter, factory-installed in a galvanized steel wall box. It arrives assembled and tested, ready to set in an exterior wall.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"backgroundColor":"paper","className":"spec-grid","style":{"spacing":{"blockGap":"0"}},"layout":{"type":"grid","columnCount":2,"minimumColumnWidth":null}} -->
<div class="wp-block-group spec-grid has-paper-background-color has-background"><!-- wp:group {"className":"spec-cell","style":{"spacing":{"blockGap":"3px"}},"layout":{"type":"default"}} -->
<div class="wp-block-group spec-cell"><!-- wp:paragraph {"className":"spec-label"} -->
<p class="spec-label">Blade</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"spec-value"} -->
<p class="spec-value">24 to 60 in.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"spec-cell","style":{"spacing":{"blockGap":"3px"}},"layout":{"type":"default"}} -->
<div class="wp-block-group spec-cell"><!-- wp:paragraph {"className":"spec-label"} -->
<p class="spec-label">Airflow, free air</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"spec-value"} -->
<p class="spec-value">Up to 41,000 CFM</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"spec-cell","style":{"spacing":{"blockGap":"3px"}},"layout":{"type":"default"}} -->
<div class="wp-block-group spec-cell"><!-- wp:paragraph {"className":"spec-label"} -->
<p class="spec-label">Motor</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"spec-value"} -->
<p class="spec-value">1/3 to 5 HP</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"spec-cell","style":{"spacing":{"blockGap":"3px"}},"layout":{"type":"default"}} -->
<div class="wp-block-group spec-cell"><!-- wp:paragraph {"className":"spec-label"} -->
<p class="spec-label">Power</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"spec-value"} -->
<p class="spec-value">115 to 460 V, 1 or 3 ph</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#model-number">Build your model</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#">Request a quote</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"className":"hero-links"} -->
<p class="hero-links"><a href="#performance">Performance table</a> <a href="#">Spec sheet, PDF</a> <a href="#">Owner's manual, PDF</a> <a href="#hazardous">Hazardous location models</a></p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"hero-checks","style":{"spacing":{"blockGap":"8px"}},"layout":{"type":"default"}} -->
<div class="wp-block-group hero-checks"><!-- wp:paragraph -->
<p>Ships fully assembled and factory tested: fan, shutter, guard and wall box.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Belts, pulleys and motor service from inside the building.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
