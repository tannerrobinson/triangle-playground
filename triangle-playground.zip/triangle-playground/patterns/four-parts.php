<?php
/**
 * Title: What is in the package
 * Slug: triangle-playground/four-parts
 * Categories: triangle
 * Description: Four cards on a gray band.
 */
?>
<!-- wp:group {"tagName":"section","backgroundColor":"paper","align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group alignfull has-paper-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"textColor":"muted","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-muted-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">One order, one part number</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Four parts, already put together</h2>
<!-- /wp:heading -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"backgroundColor":"white","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}}} -->
<div class="wp-block-column has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"textColor":"link-blue","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-link-blue-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">VIG series</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">OSHA guard</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"body","fontSize":"small"} -->
<p class="has-body-color has-text-color has-small-font-size">Inside the building. Keeps people clear of moving parts.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"backgroundColor":"white","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}}} -->
<div class="wp-block-column has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"textColor":"link-blue","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-link-blue-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">VI series</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Belt-drive exhaust fan</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"body","fontSize":"small"} -->
<p class="has-body-color has-text-color has-small-font-size">Heavy-duty fan with an automatic belt tensioner on ODP and TE motors up to 1 1/2 HP.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"backgroundColor":"white","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}}} -->
<div class="wp-block-column has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"textColor":"link-blue","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-link-blue-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Wall box</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Galvanized wall box</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"body","fontSize":"small"} -->
<p class="has-body-color has-text-color has-small-font-size">Heavy-gauge galvanized housing with a bronze powder-coated rolled inlet venturi.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"backgroundColor":"white","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}}} -->
<div class="wp-block-column has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"textColor":"link-blue","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-link-blue-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">IWS series</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Gravity shutter</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"body","fontSize":"small"} -->
<p class="has-body-color has-text-color has-small-font-size">Outside the building. Opens with airflow and closes against backdrafts.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
