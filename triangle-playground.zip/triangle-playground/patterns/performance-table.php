<?php
/**
 * Title: Performance table
 * Slug: triangle-playground/performance-table
 * Categories: triangle
 * Description: Airflow by motor at each static pressure.
 */
?>
<!-- wp:group {"tagName":"section","backgroundColor":"white","align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"0","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group alignfull has-white-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"textColor":"muted","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-muted-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Models and performance</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"performance"} -->
<h2 id="performance" class="wp-block-heading">Every size, motor and part number</h2>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"constrained","contentSize":"680px","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"textColor":"body"} -->
<p class="has-body-color has-text-color">Open a blade size to see airflow and the part number for each motor. 1-phase motors are 115/230 V and 3-phase are 230/460 V unless noted. ODP is open drip-proof, TE is totally enclosed, and HL is hazardous location (made to order, non-returnable).</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"size-list","style":{"spacing":{"blockGap":"0"}},"layout":{"type":"default"}} -->
<div class="wp-block-group size-list"><!-- wp:details -->
<details class="wp-block-details"><summary>24 in. blade<span class="sum-note">1 motor · 30 3/4 x 30 3/4 in. over bolt heads</span></summary><!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Airflow in CFM at each static pressure (inches of water)</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Motor HP</th><th class="has-text-align-right" data-align="right">0 in.</th><th class="has-text-align-right" data-align="right">0.125 in.</th><th class="has-text-align-right" data-align="right">0.25 in.</th><th class="has-text-align-right" data-align="right">0.5 in.</th><th class="has-text-align-right" data-align="right">Weight, lb</th></tr></thead><tbody><tr><td>1/2</td><td class="has-text-align-right" data-align="right">5,000</td><td class="has-text-align-right" data-align="right">4,250</td><td class="has-text-align-right" data-align="right">3,430</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">170</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Part numbers</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes is-part-numbers"} -->
<figure class="wp-block-table is-style-stripes is-part-numbers"><table><thead><tr><th>Motor HP</th><th>1-phase ODP</th><th>1-phase TE</th><th>3-phase ODP</th><th>3-phase TE</th><th>HL 1-phase</th><th>HL 3-phase</th></tr></thead><tbody><tr><td>1/2</td><td>VIK2413-V (115 V)<br>VIK2413-W (230 V)</td><td>VIK2413T-U</td><td>VIK2413-X</td><td>VIK2413T-X</td><td>VIK2413HL-U</td><td>VIK2413HL-X</td></tr></tbody></table></figure>
<!-- /wp:table --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>30 in. blade<span class="sum-note">2 motors · 34 3/4 x 34 3/4 in. over bolt heads</span></summary><!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Airflow in CFM at each static pressure (inches of water)</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Motor HP</th><th class="has-text-align-right" data-align="right">0 in.</th><th class="has-text-align-right" data-align="right">0.125 in.</th><th class="has-text-align-right" data-align="right">0.25 in.</th><th class="has-text-align-right" data-align="right">0.5 in.</th><th class="has-text-align-right" data-align="right">Weight, lb</th></tr></thead><tbody><tr><td>1/2</td><td class="has-text-align-right" data-align="right">9,180</td><td class="has-text-align-right" data-align="right">7,880</td><td class="has-text-align-right" data-align="right">6,430</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">181</td></tr><tr><td>3/4</td><td class="has-text-align-right" data-align="right">9,840</td><td class="has-text-align-right" data-align="right">8,650</td><td class="has-text-align-right" data-align="right">7,190</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">185</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Part numbers</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes is-part-numbers"} -->
<figure class="wp-block-table is-style-stripes is-part-numbers"><table><thead><tr><th>Motor HP</th><th>1-phase ODP</th><th>1-phase TE</th><th>3-phase ODP</th><th>3-phase TE</th><th>HL 1-phase</th><th>HL 3-phase</th></tr></thead><tbody><tr><td>1/2</td><td>VIK3013-V (115 V)<br>VIK3013-W (230 V)</td><td>VIK3013T-U</td><td>VIK3013-X</td><td>VIK3013T-X</td><td>VIK3013HL-U</td><td>VIK3013HL-X</td></tr><tr><td>3/4</td><td>VIK3014-U</td><td>VIK3014T-U</td><td>VIK3014-X</td><td>VIK3014T-X</td><td>VIK3014HL-U</td><td>VIK3014HL-X</td></tr></tbody></table></figure>
<!-- /wp:table --></details>
<!-- /wp:details -->

<!-- wp:details {"showContent":true} -->
<details class="wp-block-details" open><summary>36 in. blade<span class="sum-note">6 motors · 40 3/4 x 40 3/4 in. over bolt heads</span></summary><!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Airflow in CFM at each static pressure (inches of water)</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Motor HP</th><th class="has-text-align-right" data-align="right">0 in.</th><th class="has-text-align-right" data-align="right">0.125 in.</th><th class="has-text-align-right" data-align="right">0.25 in.</th><th class="has-text-align-right" data-align="right">0.5 in.</th><th class="has-text-align-right" data-align="right">Weight, lb</th></tr></thead><tbody><tr><td>1/2</td><td class="has-text-align-right" data-align="right">10,800</td><td class="has-text-align-right" data-align="right">8,840</td><td class="has-text-align-right" data-align="right">6,550</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">200</td></tr><tr><td>3/4</td><td class="has-text-align-right" data-align="right">12,600</td><td class="has-text-align-right" data-align="right">10,550</td><td class="has-text-align-right" data-align="right">6,880</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">205</td></tr><tr><td>1</td><td class="has-text-align-right" data-align="right">13,340</td><td class="has-text-align-right" data-align="right">11,500</td><td class="has-text-align-right" data-align="right">9,160</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">215</td></tr><tr><td>1 1/2</td><td class="has-text-align-right" data-align="right">14,790</td><td class="has-text-align-right" data-align="right">13,080</td><td class="has-text-align-right" data-align="right">11,440</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">230</td></tr><tr><td>2</td><td class="has-text-align-right" data-align="right">16,900</td><td class="has-text-align-right" data-align="right">15,440</td><td class="has-text-align-right" data-align="right">13,380</td><td class="has-text-align-right" data-align="right">8,250</td><td class="has-text-align-right" data-align="right">270</td></tr><tr><td>3</td><td class="has-text-align-right" data-align="right">15,400</td><td class="has-text-align-right" data-align="right">14,200</td><td class="has-text-align-right" data-align="right">13,000</td><td class="has-text-align-right" data-align="right">9,970</td><td class="has-text-align-right" data-align="right">327</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Part numbers</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes is-part-numbers"} -->
<figure class="wp-block-table is-style-stripes is-part-numbers"><table><thead><tr><th>Motor HP</th><th>1-phase ODP</th><th>1-phase TE</th><th>3-phase ODP</th><th>3-phase TE</th><th>HL 1-phase</th><th>HL 3-phase</th></tr></thead><tbody><tr><td>1/2</td><td>VIK3613-V (115 V)<br>VIK3613-W (230 V)</td><td>VIK3613T-U</td><td>VIK3613-X</td><td>VIK3613T-X</td><td>VIK3613HL-U</td><td>VIK3613HL-X</td></tr><tr><td>3/4</td><td>VIK3614-U</td><td>VIK3614T-U</td><td>VIK3614-X</td><td>VIK3614T-X</td><td>VIK3614HL-U</td><td>VIK3614HL-X</td></tr><tr><td>1</td><td>VIK3615-U</td><td>VIK3615T-U</td><td>VIK3615-X</td><td>VIK3615T-X</td><td>VIK3615HL-U</td><td>VIK3615HL-X</td></tr><tr><td>1 1/2</td><td>VIK3616-U</td><td>VIK3616T-U</td><td>VIK3616-X</td><td>VIK3616T-X</td><td>VIK3616HL-U</td><td>VIK3616HL-X</td></tr><tr><td>2</td><td>VIK3617-U</td><td>n/a</td><td>VIK3617-X</td><td>VIK3617T-X</td><td>VIK3617HL-U</td><td>VIK3617HL-X</td></tr><tr><td>3</td><td>VIK3618-U</td><td>n/a</td><td>VIK3618-X</td><td>VIK3618T-X</td><td>n/a</td><td>VIK3618HL-X</td></tr></tbody></table></figure>
<!-- /wp:table --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>42 in. blade<span class="sum-note">5 motors · 46 3/4 x 46 3/4 in. over bolt heads</span></summary><!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Airflow in CFM at each static pressure (inches of water)</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Motor HP</th><th class="has-text-align-right" data-align="right">0 in.</th><th class="has-text-align-right" data-align="right">0.125 in.</th><th class="has-text-align-right" data-align="right">0.25 in.</th><th class="has-text-align-right" data-align="right">0.5 in.</th><th class="has-text-align-right" data-align="right">Weight, lb</th></tr></thead><tbody><tr><td>1/2</td><td class="has-text-align-right" data-align="right">13,160</td><td class="has-text-align-right" data-align="right">10,050</td><td class="has-text-align-right" data-align="right">4,270</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">230</td></tr><tr><td>3/4</td><td class="has-text-align-right" data-align="right">15,050</td><td class="has-text-align-right" data-align="right">12,320</td><td class="has-text-align-right" data-align="right">7,700</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">235</td></tr><tr><td>1</td><td class="has-text-align-right" data-align="right">16,570</td><td class="has-text-align-right" data-align="right">14,210</td><td class="has-text-align-right" data-align="right">10,900</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">250</td></tr><tr><td>1 1/2</td><td class="has-text-align-right" data-align="right">17,950</td><td class="has-text-align-right" data-align="right">15,760</td><td class="has-text-align-right" data-align="right">13,030</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">265</td></tr><tr><td>2</td><td class="has-text-align-right" data-align="right">22,050</td><td class="has-text-align-right" data-align="right">20,040</td><td class="has-text-align-right" data-align="right">18,150</td><td class="has-text-align-right" data-align="right">11,790</td><td class="has-text-align-right" data-align="right">290</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Part numbers</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes is-part-numbers"} -->
<figure class="wp-block-table is-style-stripes is-part-numbers"><table><thead><tr><th>Motor HP</th><th>1-phase ODP</th><th>1-phase TE</th><th>3-phase ODP</th><th>3-phase TE</th><th>HL 1-phase</th><th>HL 3-phase</th></tr></thead><tbody><tr><td>1/2</td><td>VIK4213-V (115 V)<br>VIK4213-W (230 V)</td><td>VIK4213T-U</td><td>VIK4213-X</td><td>VIK4213T-X</td><td>VIK4213HL-U</td><td>VIK4213HL-X</td></tr><tr><td>3/4</td><td>VIK4214-U</td><td>VIK4214T-U</td><td>VIK4214-X</td><td>VIK4214T-X</td><td>VIK4214HL-U</td><td>VIK4214HL-X</td></tr><tr><td>1</td><td>VIK4215-U</td><td>VIK4215T-U</td><td>VIK4215-X</td><td>VIK4215T-X</td><td>VIK4215HL-U</td><td>VIK4215HL-X</td></tr><tr><td>1 1/2</td><td>VIK4216-U</td><td>VIK4216T-U</td><td>VIK4216-X</td><td>VIK4216T-X</td><td>VIK4216HL-U</td><td>VIK4216HL-X</td></tr><tr><td>2</td><td>VIK4217-U</td><td>VIK4217T-U</td><td>VIK4217-X</td><td>VIK4217T-X</td><td>n/a</td><td>n/a</td></tr></tbody></table></figure>
<!-- /wp:table --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>48 in. blade<span class="sum-note">6 motors · 52 3/4 x 52 3/4 in. over bolt heads</span></summary><!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Airflow in CFM at each static pressure (inches of water)</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Motor HP</th><th class="has-text-align-right" data-align="right">0 in.</th><th class="has-text-align-right" data-align="right">0.125 in.</th><th class="has-text-align-right" data-align="right">0.25 in.</th><th class="has-text-align-right" data-align="right">0.5 in.</th><th class="has-text-align-right" data-align="right">Weight, lb</th></tr></thead><tbody><tr><td>3/4</td><td class="has-text-align-right" data-align="right">19,100</td><td class="has-text-align-right" data-align="right">14,300</td><td class="has-text-align-right" data-align="right">6,160</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">280</td></tr><tr><td>1</td><td class="has-text-align-right" data-align="right">20,600</td><td class="has-text-align-right" data-align="right">16,000</td><td class="has-text-align-right" data-align="right">7,770</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">285</td></tr><tr><td>1 1/2</td><td class="has-text-align-right" data-align="right">21,500</td><td class="has-text-align-right" data-align="right">16,400</td><td class="has-text-align-right" data-align="right">10,400</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">300</td></tr><tr><td>2</td><td class="has-text-align-right" data-align="right">21,100</td><td class="has-text-align-right" data-align="right">19,000</td><td class="has-text-align-right" data-align="right">16,500</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">325</td></tr><tr><td>3</td><td class="has-text-align-right" data-align="right">23,700</td><td class="has-text-align-right" data-align="right">21,500</td><td class="has-text-align-right" data-align="right">19,300</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">410</td></tr><tr><td>5</td><td class="has-text-align-right" data-align="right">28,800</td><td class="has-text-align-right" data-align="right">26,800</td><td class="has-text-align-right" data-align="right">24,500</td><td class="has-text-align-right" data-align="right">18,400</td><td class="has-text-align-right" data-align="right">425</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Part numbers</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes is-part-numbers"} -->
<figure class="wp-block-table is-style-stripes is-part-numbers"><table><thead><tr><th>Motor HP</th><th>1-phase ODP</th><th>1-phase TE</th><th>3-phase ODP</th><th>3-phase TE</th><th>HL 1-phase</th><th>HL 3-phase</th></tr></thead><tbody><tr><td>3/4</td><td>VIK4814-U</td><td>VIK4814T-U</td><td>VIK4814-X</td><td>VIK4814T-X</td><td>VIK4814HL-U</td><td>VIK4814HL-X</td></tr><tr><td>1</td><td>VIK4815-U</td><td>VIK4815T-U</td><td>VIK4815-X</td><td>VIK4815T-X</td><td>VIK4815HL-U</td><td>VIK4815HL-X</td></tr><tr><td>1 1/2</td><td>VIK4816-U</td><td>VIK4816T-U</td><td>VIK4816-X</td><td>VIK4816T-X</td><td>VIK4816HL-U</td><td>VIK4816HL-X</td></tr><tr><td>2</td><td>VIK4817-U</td><td>VIK4817T-U</td><td>VIK4817-X</td><td>VIK4817T-X</td><td>VIK4817HL-U</td><td>VIK4817HL-X</td></tr><tr><td>3</td><td>VIK4818-U</td><td>n/a</td><td>VIK4818-X</td><td>VIK4818T-X</td><td>VIK4818HL-U</td><td>VIK4818HL-X</td></tr><tr><td>5</td><td>VIK4819-W (230 V)</td><td>n/a</td><td>VIK4819-X</td><td>VIK4819T-X</td><td>n/a</td><td>VIK4819HL-X</td></tr></tbody></table></figure>
<!-- /wp:table --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>54 in. blade<span class="sum-note">3 motors · 62 7/8 x 62 7/8 in. over bolt heads</span></summary><!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Airflow in CFM at each static pressure (inches of water)</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Motor HP</th><th class="has-text-align-right" data-align="right">0 in.</th><th class="has-text-align-right" data-align="right">0.125 in.</th><th class="has-text-align-right" data-align="right">0.25 in.</th><th class="has-text-align-right" data-align="right">0.5 in.</th><th class="has-text-align-right" data-align="right">Weight, lb</th></tr></thead><tbody><tr><td>2</td><td class="has-text-align-right" data-align="right">25,500</td><td class="has-text-align-right" data-align="right">22,300</td><td class="has-text-align-right" data-align="right">19,900</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">460</td></tr><tr><td>3</td><td class="has-text-align-right" data-align="right">29,800</td><td class="has-text-align-right" data-align="right">27,100</td><td class="has-text-align-right" data-align="right">24,600</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">470</td></tr><tr><td>5</td><td class="has-text-align-right" data-align="right">37,300</td><td class="has-text-align-right" data-align="right">35,000</td><td class="has-text-align-right" data-align="right">32,600</td><td class="has-text-align-right" data-align="right">26,500</td><td class="has-text-align-right" data-align="right">490</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Part numbers</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes is-part-numbers"} -->
<figure class="wp-block-table is-style-stripes is-part-numbers"><table><thead><tr><th>Motor HP</th><th>1-phase ODP</th><th>1-phase TE</th><th>3-phase ODP</th><th>3-phase TE</th><th>HL 1-phase</th><th>HL 3-phase</th></tr></thead><tbody><tr><td>2</td><td>VIK5417-U</td><td>VIK5417T-U</td><td>VIK5417-X</td><td>VIK5417T-X</td><td>VIK5417HL-U</td><td>VIK5417HL-X</td></tr><tr><td>3</td><td>VIK5418-U</td><td>n/a</td><td>VIK5418-X</td><td>VIK5418T-X</td><td>VIK5418HL-U</td><td>VIK5418HL-X</td></tr><tr><td>5</td><td>VIK5419-W (230 V)</td><td>n/a</td><td>VIK5419-X</td><td>VIK5419T-X</td><td>n/a</td><td>VIK5419HL-X</td></tr></tbody></table></figure>
<!-- /wp:table --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>60 in. blade<span class="sum-note">3 motors · 68 7/8 x 68 7/8 in. over bolt heads</span></summary><!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Airflow in CFM at each static pressure (inches of water)</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Motor HP</th><th class="has-text-align-right" data-align="right">0 in.</th><th class="has-text-align-right" data-align="right">0.125 in.</th><th class="has-text-align-right" data-align="right">0.25 in.</th><th class="has-text-align-right" data-align="right">0.5 in.</th><th class="has-text-align-right" data-align="right">Weight, lb</th></tr></thead><tbody><tr><td>2</td><td class="has-text-align-right" data-align="right">30,600</td><td class="has-text-align-right" data-align="right">27,100</td><td class="has-text-align-right" data-align="right">23,150</td><td class="has-text-align-right" data-align="right">n/a</td><td class="has-text-align-right" data-align="right">555</td></tr><tr><td>3</td><td class="has-text-align-right" data-align="right">34,500</td><td class="has-text-align-right" data-align="right">31,600</td><td class="has-text-align-right" data-align="right">28,500</td><td class="has-text-align-right" data-align="right">19,250</td><td class="has-text-align-right" data-align="right">565</td></tr><tr><td>5</td><td class="has-text-align-right" data-align="right">41,000</td><td class="has-text-align-right" data-align="right">38,600</td><td class="has-text-align-right" data-align="right">36,100</td><td class="has-text-align-right" data-align="right">30,300</td><td class="has-text-align-right" data-align="right">575</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"className":"table-label"} -->
<p class="table-label">Part numbers</p>
<!-- /wp:paragraph -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes is-part-numbers"} -->
<figure class="wp-block-table is-style-stripes is-part-numbers"><table><thead><tr><th>Motor HP</th><th>1-phase ODP</th><th>1-phase TE</th><th>3-phase ODP</th><th>3-phase TE</th><th>HL 1-phase</th><th>HL 3-phase</th></tr></thead><tbody><tr><td>2</td><td>VIK6017-U</td><td>VIK6017T-U</td><td>VIK6017-X</td><td>VIK6017T-X</td><td>VIK6017HL-U</td><td>VIK6017HL-X</td></tr><tr><td>3</td><td>VIK6018-U</td><td>n/a</td><td>VIK6018-X</td><td>VIK6018T-X</td><td>VIK6018HL-U</td><td>VIK6018HL-X</td></tr><tr><td>5</td><td>VIK6019-W (230 V)</td><td>n/a</td><td>VIK6019-X</td><td>VIK6019T-X</td><td>n/a</td><td>VIK6019HL-X</td></tr></tbody></table></figure>
<!-- /wp:table --></details>
<!-- /wp:details --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="#">Full spec sheet, all sizes (PDF)</a></p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
