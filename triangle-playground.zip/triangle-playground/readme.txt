=== Triangle Playground ===
A practice block theme for Triangle Engineering.

What is where:
- theme.json: brand colors, fonts, sizes and spacing. The editor only offers these colors.
- templates/: page layouts. "Product page (no title)" is used by the VIK page.
- parts/: the header and footer.
- patterns/: every section of the VIK page, reusable from the inserter under "Triangle".
- inc/vik-page.html: the sample page, created on activation.

Updating: upload a newer ZIP and choose "Replace installed with uploaded". If you
haven't edited the sample VIK page, it updates to the new version too. If you have,
your edits are kept.

Fonts: Montserrat stands in for Gotham, which is licensed and can't be bundled here.
Photos and fonts load from the internet.
