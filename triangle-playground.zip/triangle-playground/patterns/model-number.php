<?php
/**
 * Title: Read a model number
 * Slug: triangle-playground/model-number
 * Categories: triangle
 * Description: Decoder table for a model number.
 */
?>
<!-- wp:group {"tagName":"section","backgroundColor":"white","align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group alignfull has-white-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"36%"} -->
<div class="wp-block-column" style="flex-basis:36%"><!-- wp:paragraph {"textColor":"muted","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-muted-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">82 standard models</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"model-number"} -->
<h2 id="model-number" class="wp-block-heading">Read a model number</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"body"} -->
<p class="has-body-color has-text-color">Every VIK model number spells out the fan. On the finished site, this becomes the model builder: pick a size, motor and power, and the page shows the model, its airflow and its drawing.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"64%"} -->
<div class="wp-block-column" style="flex-basis:64%"><!-- wp:table {"hasFixedLayout":false,"className":"is-decoder"} -->
<figure class="wp-block-table is-decoder"><table><thead><tr><th>VIK</th><th>36</th><th>1</th><th>5</th><th>-X</th></tr></thead><tbody><tr><td>Series</td><td>36 in. blade</td><td>Single speed</td><td>Motor code: 1 HP</td><td>Three phase, 230/460 V</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"textColor":"body","fontSize":"small"} -->
<p class="has-body-color has-text-color has-small-font-size">A <strong>T</strong> after the digits means a totally enclosed motor (VIK3615T-X). <strong>HL</strong> means hazardous location (VIK3615HL-X). <strong>-U</strong> is single phase, 115/230 V.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
