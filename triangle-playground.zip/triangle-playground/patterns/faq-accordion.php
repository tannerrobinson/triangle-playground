<?php
/**
 * Title: Questions (accordion)
 * Slug: triangle-playground/faq-accordion
 * Categories: triangle
 * Description: Collapsible questions built with the Details block.
 */
?>
<!-- wp:group {"tagName":"section","backgroundColor":"white","align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group alignfull has-white-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"32%"} -->
<div class="wp-block-column" style="flex-basis:32%"><!-- wp:heading -->
<h2 class="wp-block-heading">VIK questions</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"68%"} -->
<div class="wp-block-column" style="flex-basis:68%"><!-- wp:details -->
<details class="wp-block-details"><summary>What comes in the package?</summary><!-- wp:paragraph {"textColor":"body"} -->
<p class="has-body-color has-text-color">A VI Series belt-drive exhaust fan, a VIG OSHA guard, an IWS gravity shutter and a galvanized wall box, assembled and tested at the factory.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Can it be serviced from inside the building?</summary><!-- wp:paragraph {"textColor":"body"} -->
<p class="has-body-color has-text-color">Yes. Belts, pulleys and the motor are all reachable from inside, so no outside lift is needed.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Is there a two-speed version?</summary><!-- wp:paragraph {"textColor":"body"} -->
<p class="has-body-color has-text-color">Yes, on 115 V single phase 1/3 and 1/2 HP models.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Can you build one to a special size?</summary><!-- wp:paragraph {"textColor":"body"} -->
<p class="has-body-color has-text-color">Yes. Ask about special wall box sizes, motor requirements or a specific airflow target.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
