<?php
/**
 * Title: Triangle footer
 * Slug: triangle-playground/footer
 * Inserter: no
 * Description: Address, links and copyright.
 */
?>
<!-- wp:group {"backgroundColor":"deep","textColor":"mist","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<div class="wp-block-group alignfull has-mist-color has-deep-background-color has-text-color has-background has-link-color" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:image {"width":"120px","linkDestination":"custom"} -->
<figure class="wp-block-image is-resized"><a href="/"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/triangle-logo.svg' ) ); ?>" alt="Triangle Engineering" style="width:120px;height:auto"/></a></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Triangle Engineering, Inc.<br>1101 North Redmond Road<br>Jacksonville, Arkansas 72076</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontFamily":"mono","fontSize":"small"} -->
<p class="has-mono-font-family has-small-font-size"><a href="tel:+15019827558">(501) 982-7558</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"textColor":"mist","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-mist-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Fans</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="#">Portable</a><br><a href="#">Wall exhaust and supply</a><br><a href="#">Roof</a><br><a href="#">High velocity</a><br><a href="#">Agricultural</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"textColor":"mist","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-mist-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Own a Triangle fan</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="#">Parts lookup</a><br><a href="#">Owner's manuals</a><br><a href="#">Troubleshooting</a><br><a href="#">Warranty</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"textColor":"mist","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-mist-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Company</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="#">About Triangle</a><br><a href="#">Where to buy</a><br><a href="#">Become a distributor</a><br><a href="#">Contact</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:separator {"backgroundColor":"mist","className":"is-style-wide"} -->
<hr class="wp-block-separator has-text-color has-mist-color has-alpha-channel-opacity has-mist-background-color has-background is-style-wide"/>
<!-- /wp:separator -->

<!-- wp:paragraph {"fontFamily":"mono","fontSize":"small"} -->
<p class="has-mono-font-family has-small-font-size">Made in the USA with domestic and foreign components. © 2026 Triangle Engineering, Inc.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
