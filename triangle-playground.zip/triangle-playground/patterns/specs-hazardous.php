<?php
/**
 * Title: Specifications and hazardous location
 * Slug: triangle-playground/specs-hazardous
 * Categories: triangle
 * Description: Spec table with a hazardous location card.
 */
?>
<!-- wp:group {"tagName":"section","backgroundColor":"paper","align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group alignfull has-paper-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%"><!-- wp:heading -->
<h2 class="wp-block-heading">Specifications</h2>
<!-- /wp:heading -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-spec-plate"} -->
<figure class="wp-block-table is-spec-plate"><table><tbody><tr><td>Blade diameters</td><td>24, 30, 36, 42, 48, 54 and 60 in.</td></tr><tr><td>Motor horsepower</td><td>1/3 to 5 HP. Other sizes on request.</td></tr><tr><td>Motor enclosures</td><td>Open drip-proof, totally enclosed or hazardous location</td></tr><tr><td>Two-speed option</td><td>115 V single phase, 1/3 and 1/2 HP</td></tr><tr><td>Single phase</td><td>115 V, 230 V</td></tr><tr><td>Three phase</td><td>230 V, 460 V. Also 208, 277, 415 and 575 V.</td></tr><tr><td>Included</td><td>VIG safety guard, IWS exhaust shutter, galvanized wall box</td></tr><tr><td>Ambient rating</td><td>Up to 110°F</td></tr></tbody></table></figure>
<!-- /wp:table --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:group {"backgroundColor":"white","anchor":"hazardous","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
<div id="hazardous" class="wp-block-group has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"textColor":"caution","fontFamily":"mono","fontSize":"small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.08em"}}} -->
<p class="has-caution-color has-text-color has-mono-font-family has-small-font-size" style="letter-spacing:0.08em;text-transform:uppercase">Classified environments</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Hazardous location models</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"body","fontSize":"small"} -->
<p class="has-body-color has-text-color has-small-font-size">Add HL to the model number: VIK3615HL-X. Explosion-proof motor rated Class I, Division 1, Group D and Class II, Groups F and G, with aluminum blades, a stationary motor mount and no wiring.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"caution","fontSize":"small"} -->
<p class="has-caution-color has-text-color has-small-font-size"><strong>Made to order and non-returnable.</strong> Airflow may run slightly below published figures.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
